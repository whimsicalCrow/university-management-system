sample zip payload
